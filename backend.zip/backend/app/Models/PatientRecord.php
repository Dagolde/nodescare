<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use App\Models\Scopes\TenantScope;

class PatientRecord extends Model
{
    use HasUuids;

    protected $fillable = [
        'tenant_id', 'patient_id', 'workflow_template_id', 'status',
        'current_department_id', 'current_step_order', 'registered_by',
        'admitted_at', 'discharged_at',
    ];

    protected $casts = [
        'admitted_at'   => 'datetime',
        'discharged_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope(new TenantScope());
    }

    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }

    public function currentDepartment()
    {
        return $this->belongsTo(Department::class, 'current_department_id');
    }

    public function workflowTemplate()
    {
        return $this->belongsTo(WorkflowTemplate::class);
    }

    public function journeyEvents()
    {
        return $this->hasMany(PatientJourneyEvent::class);
    }

    public function invoices()
    {
        return $this->hasMany(Invoice::class);
    }
}
