<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use App\Models\Scopes\TenantScope;

class PatientJourneyEvent extends Model
{
    use HasUuids;

    protected $fillable = [
        'tenant_id', 'patient_record_id', 'event_type',
        'from_department_id', 'to_department_id', 'notes', 'performed_by',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope(new TenantScope());
    }

    public function patientRecord()
    {
        return $this->belongsTo(PatientRecord::class);
    }

    public function fromDepartment()
    {
        return $this->belongsTo(Department::class, 'from_department_id');
    }

    public function toDepartment()
    {
        return $this->belongsTo(Department::class, 'to_department_id');
    }
}
