<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Models\AuditLog;
use App\Models\DispensingRecord;
use App\Models\LabResult;
use App\Models\Notification;
use App\Models\PatientDocument;
use App\Models\PatientJourneyEvent;
use App\Models\PatientRecord;
use App\Services\WorkflowService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ClinicalController extends Controller
{
    protected WorkflowService $workflowService;

    public function __construct(WorkflowService $workflowService)
    {
        $this->workflowService = $workflowService;
    }

    // -------------------------------------------------------------------------
    // Task 12.1 — Doctor Appointment Endpoints
    // -------------------------------------------------------------------------

    /**
     * Book a new appointment.
     * POST /api/v1/appointments
     *
     * Requirements: 7.7, 7.8, 7.9
     */
    public function bookAppointment(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'patient_id'        => 'required|uuid|exists:patients,id',
            'patient_record_id' => 'nullable|uuid|exists:patient_records,id',
            'scheduled_at'      => 'required|date',
            'notes'             => 'nullable|string|max:5000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'VALIDATION_ERROR',
                    'message' => 'The given data was invalid.',
                    'details' => $validator->errors(),
                ],
            ], 422);
        }

        // Requirement 7.9 — reject past appointments
        if (now()->gte($request->input('scheduled_at'))) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'PAST_APPOINTMENT',
                    'message' => 'Appointment date must be in the future.',
                ],
            ], 422);
        }

        /** @var \App\Models\User $user */
        $user = $request->user();

        try {
            DB::beginTransaction();

            $appointment = Appointment::create([
                'id'           => \Illuminate\Support\Str::uuid(),
                'tenant_id'    => app('current_tenant_id'),
                'patient_id'   => $request->input('patient_id'),
                'doctor_id'    => $user->id,
                'department_id' => $user->department_id,
                'scheduled_at' => $request->input('scheduled_at'),
                'status'       => 'scheduled',
                'notes'        => $request->input('notes'),
            ]);

            AuditLog::create([
                'tenant_id'     => app('current_tenant_id'),
                'actor_id'      => $user->id,
                'actor_role'    => $user->role,
                'action'        => 'appointment.created',
                'resource_type' => 'Appointment',
                'resource_id'   => $appointment->id,
                'description'   => "Appointment booked by Dr. {$user->name}",
                'ip_address'    => $request->ip(),
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'data'    => $appointment->load(['patient', 'patientRecord', 'doctor']),
                'message' => 'Appointment booked successfully',
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'APPOINTMENT_BOOKING_ERROR',
                    'message' => 'Failed to book appointment',
                    'details' => config('app.debug') ? $e->getMessage() : null,
                ],
            ], 500);
        }
    }

    /**
     * List appointments for the authenticated doctor.
     * GET /api/v1/appointments
     *
     * Requirements: 7.7
     */
    public function listAppointments(Request $request): JsonResponse
    {
        /** @var \App\Models\User $user */
        $user = $request->user();

        $appointments = Appointment::where('doctor_id', $user->id)
            ->with(['patient', 'patientRecord'])
            ->orderBy('scheduled_at', 'asc')
            ->paginate(20);

        return response()->json([
            'success' => true,
            'data'    => $appointments->items(),
            'meta'    => [
                'pagination' => [
                    'current_page' => $appointments->currentPage(),
                    'per_page'     => $appointments->perPage(),
                    'total'        => $appointments->total(),
                    'last_page'    => $appointments->lastPage(),
                ],
            ],
        ]);
    }

    /**
     * Update an appointment.
     * PATCH /api/v1/appointments/{id}
     *
     * Requirements: 7.7
     */
    public function updateAppointment(string $id, Request $request): JsonResponse
    {
        /** @var \App\Models\User $user */
        $user = $request->user();

        $appointment = Appointment::find($id);

        if (!$appointment) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'NOT_FOUND',
                    'message' => 'Appointment not found',
                ],
            ], 404);
        }

        // Only the owning doctor may update
        if ($appointment->doctor_id !== $user->id) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'FORBIDDEN',
                    'message' => 'You are not authorised to update this appointment',
                ],
            ], 403);
        }

        $validator = Validator::make($request->all(), [
            'scheduled_at' => 'sometimes|date',
            'status'       => 'sometimes|in:scheduled,completed,cancelled,no_show',
            'notes'        => 'sometimes|nullable|string|max:5000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'VALIDATION_ERROR',
                    'message' => 'The given data was invalid.',
                    'details' => $validator->errors(),
                ],
            ], 422);
        }

        // Requirement 7.9 — reject past scheduled_at if provided
        if ($request->has('scheduled_at') && now()->gte($request->input('scheduled_at'))) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'PAST_APPOINTMENT',
                    'message' => 'Appointment date must be in the future.',
                ],
            ], 422);
        }

        try {
            $appointment->update($request->only(['scheduled_at', 'status', 'notes']));

            AuditLog::create([
                'actor_id'      => $user->id,
                'actor_role'    => $user->role,
                'action'        => 'appointment.updated',
                'resource_type' => 'Appointment',
                'resource_id'   => $appointment->id,
                'description'   => "Appointment {$appointment->id} updated by Dr. {$user->name}",
                'ip_address'    => $request->ip(),
                'metadata'      => $request->only(['scheduled_at', 'status', 'notes']),
            ]);

            return response()->json([
                'success' => true,
                'data'    => $appointment->fresh(['patient', 'patientRecord', 'doctor']),
                'message' => 'Appointment updated successfully',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'APPOINTMENT_UPDATE_ERROR',
                    'message' => 'Failed to update appointment',
                    'details' => config('app.debug') ? $e->getMessage() : null,
                ],
            ], 500);
        }
    }

    // -------------------------------------------------------------------------
    // Task 12.2 — Pharmacy Dispensing Endpoint
    // -------------------------------------------------------------------------

    /**
     * Record medication dispensing for a patient record.
     * POST /api/v1/patient-records/{id}/dispensing
     *
     * Requirements: 8.1, 8.2, 8.3, 8.4
     */
    public function recordDispensing(string $id, Request $request): JsonResponse
    {
        $patientRecord = PatientRecord::find($id);

        if (!$patientRecord) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'NOT_FOUND',
                    'message' => 'Patient record not found',
                ],
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'drug_name'    => 'required|string|max:255',
            'dosage'       => 'required|string|max:100',
            'quantity'     => 'required|string|max:100',
            'dispensed_at' => 'required|date',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'VALIDATION_ERROR',
                    'message' => 'The given data was invalid.',
                    'details' => $validator->errors(),
                ],
            ], 422);
        }

        /** @var \App\Models\User $user */
        $user = $request->user();

        try {
            DB::beginTransaction();

            // Requirement 8.4 — check for prescription notes in journey events
            $hasPrescriptionNotes = PatientJourneyEvent::where('patient_record_id', $patientRecord->id)
                ->whereNotNull('metadata->prescription_notes')
                ->exists();

            if (!$hasPrescriptionNotes) {
                // Log anomaly to audit log
                AuditLog::create([
                    'actor_id'      => $user->id,
                    'actor_role'    => $user->role,
                    'action'        => 'anomaly.missing_prescription_notes',
                    'resource_type' => 'PatientRecord',
                    'resource_id'   => $patientRecord->id,
                    'description'   => "Dispensing recorded for patient record {$patientRecord->id} without prescription notes",
                    'ip_address'    => $request->ip(),
                    'metadata'      => [
                        'patient_record_id' => $patientRecord->id,
                        'pharmacist_id'     => $user->id,
                    ],
                ]);
            }

            // Record dispensing
            $dispensingRecord = DispensingRecord::create([
                'id'                => \Illuminate\Support\Str::uuid(),
                'tenant_id'         => app('current_tenant_id'),
                'patient_record_id' => $patientRecord->id,
                'pharmacist_id'     => $user->id,
                'medications'       => $request->input('medications', []),
                'notes'             => $request->input('notes'),
            ]);

            PatientJourneyEvent::create([
                'id'                 => \Illuminate\Support\Str::uuid(),
                'tenant_id'          => app('current_tenant_id'),
                'patient_record_id'  => $patientRecord->id,
                'from_department_id' => $user->department_id,
                'to_department_id'   => $user->department_id,
                'event_type'         => 'note_added',
                'performed_by'       => $user->id,
                'notes'              => 'Dispensing recorded.',
            ]);

            AuditLog::create([
                'tenant_id'     => app('current_tenant_id'),
                'actor_id'      => $user->id,
                'actor_role'    => $user->role,
                'action'        => 'dispensing.recorded',
                'resource_type' => 'DispensingRecord',
                'resource_id'   => $dispensingRecord->id,
                'description'   => "Dispensing recorded by {$user->name}",
                'ip_address'    => $request->ip(),
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'data'    => $dispensingRecord->load(['patientRecord', 'pharmacist']),
                'message' => 'Dispensing recorded successfully',
                'warning' => $hasPrescriptionNotes ? null : 'No prescription notes found for this patient record.',
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'DISPENSING_ERROR',
                    'message' => 'Failed to record dispensing',
                    'details' => config('app.debug') ? $e->getMessage() : null,
                ],
            ], 500);
        }
    }

    // -------------------------------------------------------------------------
    // Task 12.3 — Laboratory Results Endpoint
    // -------------------------------------------------------------------------

    /**
     * Record lab results for a patient record.
     * POST /api/v1/patient-records/{id}/lab-results
     *
     * Requirements: 9.1, 9.2, 9.3, 9.4, 9.5
     */
    public function recordLabResults(string $id, Request $request): JsonResponse
    {
        $patientRecord = PatientRecord::find($id);

        if (!$patientRecord) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'NOT_FOUND',
                    'message' => 'Patient record not found',
                ],
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'test_name'           => 'required|string|max:255',
            'result_value'        => 'required|string',
            'reference_range'     => 'nullable|string|max:255',
            'resulted_at'         => 'required|date',
            // Requirement 9.3 — optional result document (object key from R2 upload)
            'result_document_key' => 'nullable|string|max:500',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'VALIDATION_ERROR',
                    'message' => 'The given data was invalid.',
                    'details' => $validator->errors(),
                ],
            ], 422);
        }

        /** @var \App\Models\User $user */
        $user = $request->user();

        try {
            DB::beginTransaction();

            // Requirement 9.5 — check for investigation notes in journey events
            $hasInvestigationNotes = PatientJourneyEvent::where('patient_record_id', $patientRecord->id)
                ->whereNotNull('metadata->investigation_notes')
                ->exists();

            if (!$hasInvestigationNotes) {
                // Log anomaly to audit log
                AuditLog::create([
                    'actor_id'      => $user->id,
                    'actor_role'    => $user->role,
                    'action'        => 'anomaly.missing_investigation_notes',
                    'resource_type' => 'PatientRecord',
                    'resource_id'   => $patientRecord->id,
                    'description'   => "Lab results recorded for patient record {$patientRecord->id} without investigation request notes",
                    'ip_address'    => $request->ip(),
                    'metadata'      => [
                        'patient_record_id' => $patientRecord->id,
                        'technician_id'     => $user->id,
                    ],
                ]);
            }

            // Record lab result
            $labResult = LabResult::create([
                'id'                => \Illuminate\Support\Str::uuid(),
                'tenant_id'         => app('current_tenant_id'),
                'patient_record_id' => $patientRecord->id,
                'technician_id'     => $user->id,
                'test_name'         => $request->input('test_name'),
                'result'            => $request->input('result'),
                'unit'              => $request->input('unit'),
                'reference_range'   => $request->input('reference_range'),
                'status'            => $request->input('status', 'completed'),
                'notes'             => $request->input('notes'),
            ]);

            if ($request->filled('result_document_key')) {
                PatientDocument::create([
                    'id'                => \Illuminate\Support\Str::uuid(),
                    'tenant_id'         => app('current_tenant_id'),
                    'patient_id'        => $patientRecord->patient_id,
                    'uploader_id'       => $user->id,
                    'document_type'     => 'lab_result',
                    'object_key'        => $request->input('result_document_key'),
                    'original_filename' => $request->input('result_document_filename', 'lab_result'),
                ]);
            }

            PatientJourneyEvent::create([
                'id'                 => \Illuminate\Support\Str::uuid(),
                'tenant_id'          => app('current_tenant_id'),
                'patient_record_id'  => $patientRecord->id,
                'from_department_id' => $user->department_id,
                'to_department_id'   => $user->department_id,
                'event_type'         => 'note_added',
                'performed_by'       => $user->id,
                'notes'              => "Lab result recorded: {$request->input('test_name')}",
            ]);

            AuditLog::create([
                'tenant_id'     => app('current_tenant_id'),
                'actor_id'      => $user->id,
                'actor_role'    => $user->role,
                'action'        => 'lab_result.recorded',
                'resource_type' => 'LabResult',
                'resource_id'   => $labResult->id,
                'description'   => "Lab result recorded by {$user->name}",
                'ip_address'    => $request->ip(),
            ]);

            // Requirement 9.4 — route back to originating doctor's department
            // Look up from_department_id in journey events to find the originating doctor's department
            $originatingEvent = PatientJourneyEvent::where('patient_record_id', $patientRecord->id)
                ->where('to_department_id', $patientRecord->current_department_id)
                ->whereNotNull('from_department_id')
                ->orderBy('created_at', 'asc')
                ->first();

            $returnDepartmentId = $originatingEvent?->from_department_id;

            if ($returnDepartmentId) {
                $patientRecord = $this->workflowService->routeToSpecificDepartment(
                    $patientRecord,
                    $returnDepartmentId,
                    $user,
                    [
                        'notes'        => 'Lab results completed. Returning to originating doctor department.',
                        'lab_result_id' => $labResult->id,
                    ]
                );

                // Notify the doctor's department staff
                $this->notifyDepartmentStaff($returnDepartmentId, $patientRecord, $labResult);
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'data'    => [
                    'lab_result'     => $labResult->load(['patientRecord', 'technician']),
                    'patient_record' => $patientRecord->fresh(['currentDepartment']),
                ],
                'message' => 'Lab results recorded successfully',
                'warning' => $hasInvestigationNotes ? null : 'No investigation request notes found for this patient record.',
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'error' => [
                    'code'    => 'LAB_RESULT_ERROR',
                    'message' => 'Failed to record lab results',
                    'details' => config('app.debug') ? $e->getMessage() : null,
                ],
            ], 500);
        }
    }

    /**
     * Notify staff in a department about updated lab results.
     */
    protected function notifyDepartmentStaff(string $departmentId, PatientRecord $patientRecord, LabResult $labResult): void
    {
        try {
            $staffMembers = \App\Models\User::where('department_id', $departmentId)
                ->where('is_active', true)
                ->get();

            foreach ($staffMembers as $staff) {
                Notification::create([
                    'recipient_id' => $staff->id,
                    'type'         => 'lab_results_ready',
                    'channel'      => 'in_app',
                    'payload'      => [
                        'patient_record_id' => $patientRecord->id,
                        'patient_id'        => $patientRecord->patient_id,
                        'lab_result_id'     => $labResult->id,
                        'test_name'         => $labResult->test_name,
                        'message'           => "Lab results ready: {$labResult->test_name}",
                    ],
                    'status'   => 'pending',
                    'attempts' => 0,
                ]);
            }
        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Log::error('Failed to notify department staff about lab results', [
                'department_id'     => $departmentId,
                'patient_record_id' => $patientRecord->id,
                'error'             => $e->getMessage(),
            ]);
        }
    }
}
