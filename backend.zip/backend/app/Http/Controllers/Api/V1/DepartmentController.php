<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Notification;
use App\Models\PatientJourneyEvent;
use App\Models\PatientRecord;
use App\Models\User;
use App\Services\WorkflowService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class DepartmentController extends Controller
{
    protected WorkflowService $workflowService;

    public function __construct(WorkflowService $workflowService)
    {
        $this->workflowService = $workflowService;
    }

    /**
     * Get department queue - patient records assigned to authenticated user's department.
     * Excludes pending_payment records. Cached with 30-second TTL.
     *
     * GET /api/v1/department/queue
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getQueue(Request $request): JsonResponse
    {
        try {
            /** @var User $user */
            $user = $request->user();

            if (!$user->department_id) {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'NO_DEPARTMENT',
                        'message' => 'User is not assigned to a department',
                    ],
                ], 400);
            }

            // Cache key includes tenant and department for isolation
            // Format: tenant:{tenant_id}:dept_queue:{dept_id}
            $cacheKey = sprintf(
                'tenant:%s:dept_queue:%s',
                app('current_tenant_id'),
                $user->department_id
            );

            $patientRecords = Cache::remember($cacheKey, 30, function () use ($user, $request) {
                return PatientRecord::with([
                    'patient',
                    'currentDepartment',
                    'workflowTemplate',
                ])
                    ->where('current_department_id', $user->department_id)
                    ->where('status', '!=', 'pending_payment')
                    ->orderBy('created_at', 'asc')
                    ->paginate(20);
            });

            return response()->json([
                'success' => true,
                'data' => $patientRecords->items(),
                'meta' => [
                    'pagination' => [
                        'current_page' => $patientRecords->currentPage(),
                        'per_page'     => $patientRecords->perPage(),
                        'total'        => $patientRecords->total(),
                        'last_page'    => $patientRecords->lastPage(),
                    ],
                    'department_id' => $user->department_id,
                    'cached' => true,
                    'cache_ttl' => 30,
                ],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'INTERNAL_ERROR',
                    'message' => 'Failed to retrieve department queue',
                    'details' => config('app.debug') ? $e->getMessage() : null,
                ],
            ], 500);
        }
    }

    /**
     * Add note to patient record journey events.
     * Validates record is assigned to user's department.
     *
     * POST /api/v1/patient-records/{id}/notes
     *
     * @param string $id
     * @param Request $request
     * @return JsonResponse
     */
    public function addNote(string $id, Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'notes' => 'required|string|max:5000',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'VALIDATION_ERROR',
                        'message' => 'The given data was invalid.',
                        'details' => $validator->errors(),
                    ],
                ], 422);
            }

            /** @var User $user */
            $user = $request->user();

            $patientRecord = PatientRecord::findOrFail($id);

            // Validate record is assigned to user's department
            if ($patientRecord->current_department_id !== $user->department_id) {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'FORBIDDEN',
                        'message' => 'Patient record is not assigned to your department',
                    ],
                ], 403);
            }

            // Prevent editing in-transit records
            if ($patientRecord->status === 'in_transit') {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'CONFLICT',
                        'message' => 'Cannot edit patient record while in transit',
                    ],
                ], 409);
            }

            DB::transaction(function () use ($patientRecord, $user, $request) {
                PatientJourneyEvent::create([
                    'tenant_id'         => app('current_tenant_id'),
                    'patient_record_id' => $patientRecord->id,
                    'from_department_id' => $user->department_id,
                    'to_department_id'  => $user->department_id,
                    'event_type'        => 'note_added',
                    'performed_by'      => $user->id,
                    'notes'             => $request->input('notes'),
                ]);

                AuditLog::create([
                    'tenant_id'     => app('current_tenant_id'),
                    'actor_id'      => $user->id,
                    'actor_role'    => $user->role,
                    'action'        => 'patient_record.note_added',
                    'resource_type' => 'PatientRecord',
                    'resource_id'   => $patientRecord->id,
                    'description'   => "Note added to patient record {$patientRecord->id} by {$user->name}",
                    'ip_address'    => $request->ip(),
                ]);
            });

            return response()->json([
                'success' => true,
                'message' => 'Note added successfully',
                'data' => $patientRecord->fresh()->load('journeyEvents'),
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'NOT_FOUND',
                    'message' => 'Patient record not found',
                ],
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'INTERNAL_ERROR',
                    'message' => 'Failed to add note',
                    'details' => config('app.debug') ? $e->getMessage() : null,
                ],
            ], 500);
        }
    }

    /**
     * Mark patient record step as complete and route to next department.
     *
     * POST /api/v1/patient-records/{id}/complete
     *
     * @param string $id
     * @param Request $request
     * @return JsonResponse
     */
    public function complete(string $id, Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'notes' => 'nullable|string|max:5000',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'VALIDATION_ERROR',
                        'message' => 'The given data was invalid.',
                        'details' => $validator->errors(),
                    ],
                ], 422);
            }

            /** @var User $user */
            $user = $request->user();

            $patientRecord = PatientRecord::findOrFail($id);

            // Validate record is assigned to user's department
            if ($patientRecord->current_department_id !== $user->department_id) {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'FORBIDDEN',
                        'message' => 'Patient record is not assigned to your department',
                    ],
                ], 403);
            }

            // Prevent editing in-transit records
            if ($patientRecord->status === 'in_transit') {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'CONFLICT',
                        'message' => 'Cannot complete patient record while in transit',
                    ],
                ], 409);
            }

            // Route to next department
            $metadata = [];
            if ($request->has('notes')) {
                $metadata['notes'] = $request->input('notes');
            }

            $updatedRecord = $this->workflowService->routeToNextDepartment(
                $patientRecord,
                $user,
                $metadata
            );

            // Invalidate queue cache for the old department (patient left) and new department (patient arrived)
            $this->invalidateDepartmentQueueCache($user->department_id);
            if ($updatedRecord->current_department_id) {
                $this->invalidateDepartmentQueueCache($updatedRecord->current_department_id);
            }

            return response()->json([
                'success' => true,
                'message' => 'Patient record completed and routed successfully',
                'data' => $updatedRecord->load(['patient', 'currentDepartment', 'journeyEvents']),
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'NOT_FOUND',
                    'message' => 'Patient record not found',
                ],
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'INTERNAL_ERROR',
                    'message' => 'Failed to complete patient record',
                    'details' => config('app.debug') ? $e->getMessage() : null,
                ],
            ], 500);
        }
    }

    /**
     * Route patient record to specific department (doctor override).
     *
     * POST /api/v1/patient-records/{id}/route
     *
     * @param string $id
     * @param Request $request
     * @return JsonResponse
     */
    public function route(string $id, Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'department_id' => 'required|uuid|exists:departments,id',
                'notes' => 'nullable|string|max:5000',
                'prescription_notes' => 'nullable|string|max:5000',
                'investigation_notes' => 'nullable|string|max:5000',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'VALIDATION_ERROR',
                        'message' => 'The given data was invalid.',
                        'details' => $validator->errors(),
                    ],
                ], 422);
            }

            /** @var User $user */
            $user = $request->user();

            // Only doctors can use override routing
            if ($user->role !== 'doctor') {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'FORBIDDEN',
                        'message' => 'Only doctors can route to specific departments',
                    ],
                ], 403);
            }

            $patientRecord = PatientRecord::findOrFail($id);

            // Validate record is assigned to user's department
            if ($patientRecord->current_department_id !== $user->department_id) {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'FORBIDDEN',
                        'message' => 'Patient record is not assigned to your department',
                    ],
                ], 403);
            }

            // Prevent editing in-transit records
            if ($patientRecord->status === 'in_transit') {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'CONFLICT',
                        'message' => 'Cannot route patient record while in transit',
                    ],
                ], 409);
            }

            // Build metadata
            $metadata = [];
            if ($request->has('notes')) {
                $metadata['notes'] = $request->input('notes');
            }
            if ($request->has('prescription_notes')) {
                $metadata['prescription_notes'] = $request->input('prescription_notes');
            }
            if ($request->has('investigation_notes')) {
                $metadata['investigation_notes'] = $request->input('investigation_notes');
            }

            $updatedRecord = $this->workflowService->routeToSpecificDepartment(
                $patientRecord,
                $request->input('department_id'),
                $user,
                $metadata
            );

            // Invalidate queue cache for the old department (patient left) and new department (patient arrived)
            $this->invalidateDepartmentQueueCache($user->department_id);
            $this->invalidateDepartmentQueueCache($request->input('department_id'));

            return response()->json([
                'success' => true,
                'message' => 'Patient record routed successfully',
                'data' => $updatedRecord->load(['patient', 'currentDepartment', 'journeyEvents']),
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'NOT_FOUND',
                    'message' => 'Patient record or department not found',
                ],
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'INTERNAL_ERROR',
                    'message' => 'Failed to route patient record',
                    'details' => config('app.debug') ? $e->getMessage() : null,
                ],
            ], 500);
        }
    }

    /**
     * Mark patient as admitted.
     *
     * POST /api/v1/patient-records/{id}/admit
     *
     * @param string $id
     * @param Request $request
     * @return JsonResponse
     */
    public function admit(string $id, Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), [
                'notes' => 'nullable|string|max:5000',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'VALIDATION_ERROR',
                        'message' => 'The given data was invalid.',
                        'details' => $validator->errors(),
                    ],
                ], 422);
            }

            /** @var User $user */
            $user = $request->user();

            // Only doctors can admit patients
            if ($user->role !== 'doctor') {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'FORBIDDEN',
                        'message' => 'Only doctors can admit patients',
                    ],
                ], 403);
            }

            $patientRecord = PatientRecord::findOrFail($id);

            // Validate record is assigned to user's department
            if ($patientRecord->current_department_id !== $user->department_id) {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'FORBIDDEN',
                        'message' => 'Patient record is not assigned to your department',
                    ],
                ], 403);
            }

            // Prevent editing in-transit records
            if ($patientRecord->status === 'in_transit') {
                return response()->json([
                    'success' => false,
                    'error' => [
                        'code' => 'CONFLICT',
                        'message' => 'Cannot admit patient record while in transit',
                    ],
                ], 409);
            }

            DB::transaction(function () use ($patientRecord, $user, $request) {
                // Update patient record status
                $patientRecord->update([
                    'status' => 'admitted',
                    'admitted_at' => now(),
                ]);

                PatientJourneyEvent::create([
                    'tenant_id'          => app('current_tenant_id'),
                    'patient_record_id'  => $patientRecord->id,
                    'from_department_id' => $user->department_id,
                    'to_department_id'   => null,
                    'event_type'         => 'admitted',
                    'performed_by'       => $user->id,
                    'notes'              => $request->input('notes'),
                ]);

                AuditLog::create([
                    'tenant_id'     => app('current_tenant_id'),
                    'actor_id'      => $user->id,
                    'actor_role'    => $user->role,
                    'action'        => 'patient_record.admitted',
                    'resource_type' => 'PatientRecord',
                    'resource_id'   => $patientRecord->id,
                    'description'   => "Patient record {$patientRecord->id} marked as admitted by {$user->name}",
                    'ip_address'    => $request->ip(),
                ]);

                // Notify Hospital Admin
                $this->notifyHospitalAdmin($patientRecord, $user);
            });

            return response()->json([
                'success' => true,
                'message' => 'Patient admitted successfully',
                'data' => $patientRecord->fresh()->load(['patient', 'currentDepartment', 'journeyEvents']),
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'NOT_FOUND',
                    'message' => 'Patient record not found',
                ],
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => [
                    'code' => 'INTERNAL_ERROR',
                    'message' => 'Failed to admit patient',
                    'details' => config('app.debug') ? $e->getMessage() : null,
                ],
            ], 500);
        }
    }

    /**
     * Invalidate department queue cache for a given department.
     *
     * @param string|null $departmentId
     * @return void
     */
    protected function invalidateDepartmentQueueCache(?string $departmentId): void
    {
        if ($departmentId) {
            $cacheKey = sprintf('tenant:%s:dept_queue:%s', app('current_tenant_id'), $departmentId);
            Cache::forget($cacheKey);
        }
    }

    /**
     * Notify Hospital Admin about patient admission.
     *
     * @param PatientRecord $patientRecord
     * @param User $doctor
     * @return void
     */
    protected function notifyHospitalAdmin(PatientRecord $patientRecord, User $doctor): void
    {
        try {
            // Get all hospital admins
            $admins = User::where('role', 'hospital_admin')
                ->where('is_active', true)
                ->get();

            foreach ($admins as $admin) {
                Notification::create([
                    'tenant_id'    => app('current_tenant_id'),
                    'recipient_id' => $admin->id,
                    'type'         => 'patient_admitted',
                    'channel'      => 'in_app',
                    'payload'      => [
                        'patient_record_id' => $patientRecord->id,
                        'patient_id'        => $patientRecord->patient_id,
                        'doctor_id'         => $doctor->id,
                        'doctor_name'       => $doctor->name,
                        'message'           => "Patient admitted by Dr. {$doctor->name}",
                    ],
                    'status'   => 'pending',
                    'attempts' => 0,
                ]);
            }
        } catch (\Exception $e) {
            // Log error but don't fail the admission operation
            \Log::error('Failed to notify hospital admin about admission', [
                'patient_record_id' => $patientRecord->id,
                'error' => $e->getMessage(),
            ]);
        }
    }
}
