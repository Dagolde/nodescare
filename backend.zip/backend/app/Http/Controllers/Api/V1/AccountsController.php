<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use App\Models\InvoicePayment;
use App\Models\PatientJourneyEvent;
use App\Models\PatientRecord;
use App\Models\WorkflowTemplateStep;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class AccountsController extends Controller
{
    /**
     * List pending_payment patient records for the accounts queue.
     * GET /api/v1/accounts/queue
     */
    public function getQueue(): JsonResponse
    {
        $records = PatientRecord::where('status', 'pending_payment')
            ->with(['patient', 'currentDepartment', 'invoices'])
            ->orderBy('created_at', 'asc')
            ->get();

        return response()->json([
            'success' => true,
            'data'    => $records,
            'meta'    => ['total' => $records->count()],
        ]);
    }

    /**
     * Create invoice for a patient record.
     * POST /api/v1/patient-records/{id}/invoices
     */
    public function createInvoice(string $id, Request $request): JsonResponse
    {
        $patientRecord = PatientRecord::find($id);

        if (!$patientRecord) {
            return response()->json([
                'success' => false,
                'error'   => ['code' => 'NOT_FOUND', 'message' => 'Patient record not found.'],
            ], 404);
        }

        $request->validate([
            'items'                  => 'required|array|min:1',
            'items.*.description'    => 'required|string|max:255',
            'items.*.unit_price'     => 'required|numeric|min:0',
            'items.*.quantity'       => 'required|integer|min:1',
        ]);

        try {
            DB::beginTransaction();

            $invoiceNumber = $this->generateInvoiceNumber();
            $totalAmount   = 0;

            foreach ($request->items as $item) {
                $totalAmount += $item['unit_price'] * $item['quantity'];
            }

            $invoice = Invoice::create([
                'id'                => Str::uuid(),
                'tenant_id'         => app('current_tenant_id'),
                'patient_record_id' => $patientRecord->id,
                'invoice_number'    => $invoiceNumber,
                'total_amount'      => $totalAmount,
                'paid_amount'       => 0,
                'status'            => 'issued',
                'created_by'        => Auth::id(),
            ]);

            foreach ($request->items as $item) {
                $totalPrice = $item['unit_price'] * $item['quantity'];
                InvoiceItem::create([
                    'id'          => Str::uuid(),
                    'tenant_id'   => app('current_tenant_id'),
                    'invoice_id'  => $invoice->id,
                    'description' => $item['description'],
                    'unit_price'  => $item['unit_price'],
                    'quantity'    => $item['quantity'],
                    'total_price' => $totalPrice,
                ]);
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'data'    => $invoice->load('items'),
                'message' => 'Invoice created successfully.',
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'error'   => ['code' => 'CREATION_FAILED', 'message' => $e->getMessage()],
            ], 500);
        }
    }

    /**
     * List invoices for a patient record.
     * GET /api/v1/patient-records/{id}/invoices
     */
    public function listInvoices(string $id): JsonResponse
    {
        $patientRecord = PatientRecord::find($id);

        if (!$patientRecord) {
            return response()->json([
                'success' => false,
                'error'   => ['code' => 'NOT_FOUND', 'message' => 'Patient record not found.'],
            ], 404);
        }

        $invoices = Invoice::where('patient_record_id', $id)
            ->with(['items', 'payments'])
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json(['success' => true, 'data' => $invoices]);
    }

    /**
     * Record a payment against an invoice.
     * POST /api/v1/invoices/{id}/payments
     */
    public function recordPayment(string $id, Request $request): JsonResponse
    {
        $invoice = Invoice::find($id);

        if (!$invoice) {
            return response()->json([
                'success' => false,
                'error'   => ['code' => 'NOT_FOUND', 'message' => 'Invoice not found.'],
            ], 404);
        }

        $request->validate([
            'amount'         => 'required|numeric|min:0.01',
            'payment_method' => 'required|in:cash,card,transfer,hmo,other',
            'reference'      => 'nullable|string|max:100',
            'notes'          => 'nullable|string',
        ]);

        try {
            DB::beginTransaction();

            $payment = InvoicePayment::create([
                'id'             => Str::uuid(),
                'tenant_id'      => app('current_tenant_id'),
                'invoice_id'     => $invoice->id,
                'amount'         => $request->amount,
                'payment_method' => $request->payment_method,
                'reference'      => $request->reference,
                'notes'          => $request->notes,
                'accountant_id'  => Auth::id(),
            ]);

            $newPaid = $invoice->paid_amount + $request->amount;
            $invoice->update([
                'paid_amount' => $newPaid,
                'status'      => $newPaid >= $invoice->total_amount ? 'paid' : 'partially_paid',
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'data'    => ['payment' => $payment, 'invoice' => $invoice->fresh(['items', 'payments'])],
                'message' => 'Payment recorded.',
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'error'   => ['code' => 'PAYMENT_FAILED', 'message' => $e->getMessage()],
            ], 500);
        }
    }

    /**
     * Settle invoice and route patient to first clinical department.
     * POST /api/v1/invoices/{id}/settle
     */
    public function settleInvoice(string $id): JsonResponse
    {
        $invoice = Invoice::with(['patientRecord'])->find($id);

        if (!$invoice) {
            return response()->json([
                'success' => false,
                'error'   => ['code' => 'NOT_FOUND', 'message' => 'Invoice not found.'],
            ], 404);
        }

        if ($invoice->status === 'paid') {
            return response()->json([
                'success' => false,
                'error'   => ['code' => 'ALREADY_PAID', 'message' => 'Invoice is already paid.'],
            ], 422);
        }

        try {
            DB::beginTransaction();

            $invoice->update(['status' => 'paid', 'paid_amount' => $invoice->total_amount]);

            $patientRecord = $invoice->patientRecord;

            // Get first step from workflow template
            $firstStep = WorkflowTemplateStep::where('template_id', $patientRecord->workflow_template_id)
                ->orderBy('step_order', 'asc')
                ->first();

            if (!$firstStep) {
                throw new \Exception('No workflow template configured for this patient record.');
            }

            $patientRecord->update([
                'status'                => 'active',
                'current_department_id' => $firstStep->department_id,
                'current_step_order'    => $firstStep->step_order,
            ]);

            PatientJourneyEvent::create([
                'id'                 => Str::uuid(),
                'tenant_id'          => app('current_tenant_id'),
                'patient_record_id'  => $patientRecord->id,
                'from_department_id' => $patientRecord->current_department_id,
                'to_department_id'   => $firstStep->department_id,
                'event_type'         => 'routed',
                'performed_by'       => Auth::id(),
                'notes'              => 'Payment settled. Patient routed to first clinical department.',
            ]);

            DB::commit();

            return response()->json([
                'success' => true,
                'data'    => [
                    'invoice'        => $invoice->fresh(['items', 'payments']),
                    'patient_record' => $patientRecord->fresh(['currentDepartment']),
                ],
                'message' => 'Invoice settled and patient routed.',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'error'   => ['code' => 'SETTLEMENT_FAILED', 'message' => $e->getMessage()],
            ], 500);
        }
    }

    /**
     * Generate PDF receipt.
     * GET /api/v1/invoices/{id}/receipt
     */
    public function generateReceipt(string $id): mixed
    {
        $invoice = Invoice::with(['items', 'payments', 'patientRecord.patient'])->find($id);

        if (!$invoice) {
            return response()->json([
                'success' => false,
                'error'   => ['code' => 'NOT_FOUND', 'message' => 'Invoice not found.'],
            ], 404);
        }

        try {
            $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('receipts.invoice', ['invoice' => $invoice]);
            return $pdf->download("receipt-{$invoice->invoice_number}.pdf");
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error'   => ['code' => 'RECEIPT_FAILED', 'message' => $e->getMessage()],
            ], 500);
        }
    }

    private function generateInvoiceNumber(): string
    {
        $date   = now()->format('Ymd');
        $prefix = "INV-{$date}-";

        $last = Invoice::where('invoice_number', 'like', $prefix . '%')
            ->orderBy('invoice_number', 'desc')
            ->first();

        $seq = $last ? ((int) substr($last->invoice_number, -4)) + 1 : 1;

        return $prefix . str_pad($seq, 4, '0', STR_PAD_LEFT);
    }
}
