<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\PatientRecord;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use PHPOpenSourceSaver\JWTAuth\Facades\JWTAuth;

class DepartmentWebController extends Controller
{
    /**
     * Department queue page - shows patient records assigned to the authenticated user's department.
     */
    public function queue(Request $request)
    {
        $user = $this->getAuthenticatedUser($request);

        if (!$user || !$user->department_id) {
            return redirect('/hospital-admin/login')
                ->withErrors(['error' => 'You must be assigned to a department to access this page.']);
        }

        $department = Department::find($user->department_id);

        $query = PatientRecord::with([
            'patient',
            'currentDepartment',
            'workflowTemplate',
        ])
            ->where('current_department_id', $user->department_id)
            ->where('status', '!=', 'pending_payment');

        if ($request->has('search') && $request->input('search')) {
            $search = $request->input('search');
            $query->whereHas('patient', function ($q) use ($search) {
                $q->where('patient_number', 'like', "%{$search}%")
                  ->orWhere('full_name', 'like', "%{$search}%");
            });
        }

        $queueRecords = $query->orderBy('created_at', 'asc')->paginate(20);

        return Inertia::render('Department/Queue', [
            'queueRecords' => $queueRecords,
            'department' => $department,
            'currentUser' => [
                'id' => $user->id,
                'name' => $user->name,
                'role' => $user->role,
                'department_id' => $user->department_id,
            ],
            'filters' => $request->only(['search']),
        ]);
    }

    /**
     * Patient detail page - shows full patient record with journey history.
     */
    public function patientDetail(Request $request, string $patientRecordId)
    {
        $user = $this->getAuthenticatedUser($request);

        if (!$user || !$user->department_id) {
            return redirect('/hospital-admin/login')
                ->withErrors(['error' => 'You must be assigned to a department to access this page.']);
        }

        $patientRecord = PatientRecord::with([
            'patient',
            'currentDepartment',
            'workflowTemplate.steps.department',
            'journeyEvents.fromDepartment',
            'journeyEvents.toDepartment',
            'journeyEvents.performer',
            'documents',
            'registrar',
        ])->findOrFail($patientRecordId);

        // Get available departments for doctor routing
        $departments = Department::where('is_active', true)
            ->where('id', '!=', $user->department_id)
            ->get(['id', 'name', 'type', 'code']);

        return Inertia::render('Department/PatientDetail', [
            'patientRecord' => $patientRecord,
            'department' => Department::find($user->department_id),
            'currentUser' => [
                'id' => $user->id,
                'name' => $user->name,
                'role' => $user->role,
                'department_id' => $user->department_id,
            ],
            'availableDepartments' => $departments,
        ]);
    }

    /**
     * Resolve the authenticated user from session.
     */
    protected function getAuthenticatedUser(Request $request)
    {
        return Auth::guard('web')->user();
    }
}
