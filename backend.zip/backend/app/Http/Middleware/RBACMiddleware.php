<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\AuditLog;
use Illuminate\Support\Facades\Log;

class RBACMiddleware
{
    /**
     * Role-based permissions mapping.
     * Maps roles to allowed route patterns.
     */
    protected array $permissions = [
        'super_admin' => ['*'], // Super admin has access to everything
        'hospital_admin' => [
            'api/v1/departments*',
            'api/v1/staff*',
            'api/v1/workflows*',
            'api/v1/reports*',
            'api/v1/audit-logs*',
            'api/v1/patients*',
            'api/v1/patient-records*',
            'api/v1/invoices*',
            'api/v1/my-department*',
        ],
        'doctor' => [
            'api/v1/department/queue',
            'api/v1/patients*',
            'api/v1/patient-records*',
            'api/v1/appointments*',
        ],
        'front_desk_officer' => [
            'api/v1/patients',
            'api/v1/patients/*/documents',
            'api/v1/department/queue',
        ],
        'accountant' => [
            'api/v1/accounts/queue',
            'api/v1/patient-records/*/invoices',
            'api/v1/invoices*',
            'api/v1/reports/financial',
        ],
        'pharmacist' => [
            'api/v1/department/queue',
            'api/v1/patient-records*',
            'api/v1/patients*',
        ],
        'lab_technician' => [
            'api/v1/department/queue',
            'api/v1/patient-records*',
            'api/v1/patients*',
        ],
        'department_staff' => [
            'api/v1/department/queue',
            'api/v1/patient-records*',
            'api/v1/patients*',
        ],
    ];

    /**
     * Handle an incoming request.
     * Enforces role-based permissions per route.
     * Returns HTTP 403 and writes audit log on unauthorized access.
     */
    public function handle(Request $request, Closure $next, ?string $requiredRole = null): Response
    {
        $user = $request->user();

        if (!$user) {
            return $this->forbiddenResponse($request, 'User not authenticated.');
        }

        $userRole = $user->role;
        $requestPath = $request->path();

        // If a specific role is required, check it
        if ($requiredRole && $userRole !== $requiredRole && $userRole !== 'super_admin') {
            $this->logUnauthorizedAccess($request, $user, "Required role: {$requiredRole}");
            return $this->forbiddenResponse($request, 'Insufficient permissions.');
        }

        // Check if user's role has permission for this route
        if (!$this->hasPermission($userRole, $requestPath)) {
            // HOD virtual role: grant access to my-department/* if user has is_hod flag
            if ($user->is_hod && $this->matchesPattern($requestPath, 'api/v1/my-department*')) {
                return $next($request);
            }

            $this->logUnauthorizedAccess($request, $user, "No permission for path: {$requestPath}");
            return $this->forbiddenResponse($request, 'Insufficient permissions.');
        }

        return $next($request);
    }

    /**
     * Check if a role has permission for a given path.
     */
    protected function hasPermission(string $role, string $path): bool
    {
        if (!isset($this->permissions[$role])) {
            return false;
        }

        $allowedPatterns = $this->permissions[$role];

        // Super admin wildcard
        if (in_array('*', $allowedPatterns)) {
            return true;
        }

        // Check each pattern
        foreach ($allowedPatterns as $pattern) {
            if ($this->matchesPattern($path, $pattern)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if a path matches a pattern (supports wildcards).
     */
    protected function matchesPattern(string $path, string $pattern): bool
    {
        // Convert pattern to regex
        $regex = str_replace('*', '.*', preg_quote($pattern, '/'));
        return (bool) preg_match('/^' . $regex . '$/', $path);
    }

    /**
     * Log unauthorized access attempt to audit log.
     */
    protected function logUnauthorizedAccess(Request $request, $user, string $reason): void
    {
        try {
            AuditLog::create([
                'actor_id' => $user->id,
                'actor_role' => $user->role,
                'action' => 'access.denied',
                'resource_type' => 'route',
                'resource_id' => null,
                'description' => "Unauthorized access attempt to {$request->method()} {$request->path()}",
                'ip_address' => $request->ip(),
                'metadata' => [
                    'reason' => $reason,
                    'method' => $request->method(),
                    'path' => $request->path(),
                    'user_agent' => $request->userAgent(),
                ],
            ]);
        } catch (\Exception $e) {
            // Log to file if database logging fails
            Log::error('Failed to write audit log', [
                'user_id' => $user->id,
                'path' => $request->path(),
                'error' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Return forbidden response.
     */
    protected function forbiddenResponse(Request $request, string $message): Response
    {
        return response()->json([
            'success' => false,
            'error' => [
                'code' => 'FORBIDDEN',
                'message' => $message,
            ],
        ], 403);
    }
}
