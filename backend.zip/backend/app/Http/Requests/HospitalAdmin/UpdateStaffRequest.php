<?php

namespace App\Http\Requests\HospitalAdmin;

use App\Rules\PasswordComplexity;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateStaffRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $staffId = $this->route('id');

        return [
            'name' => 'nullable|string|max:255',
            'email' => [
                'nullable',
                'email',
                'max:255',
                Rule::unique('users', 'email')->ignore($staffId),
            ],
            'phone' => 'nullable|string|max:20',
            'password' => ['nullable', 'string', 'min:10', new PasswordComplexity()],
            'role' => [
                'nullable',
                'string',
                Rule::in([
                    'hospital_admin',
                    'doctor',
                    'front_desk_officer',
                    'accountant',
                    'pharmacist',
                    'lab_technician',
                    'department_staff',
                ]),
            ],
            'department_id' => 'nullable|uuid|exists:departments,id',
            'is_active' => 'nullable|boolean',
            'is_hod' => 'nullable|boolean',
        ];
    }
}
