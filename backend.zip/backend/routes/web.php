<?php

use App\Http\Controllers\SuperAdminAuthController;
use App\Http\Controllers\SuperAdminWebController;
use App\Http\Controllers\HospitalAdminAuthController;
use App\Http\Controllers\HospitalAdminWebController;
use App\Http\Controllers\AccountsWebController;
use App\Http\Controllers\DepartmentWebController;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', function () {
    return Inertia::render('Welcome');
});

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', function () {
        return Inertia::render('Dashboard');
    })->name('dashboard');
});

// Super Admin login (no auth required)
Route::get('/admin/login', function () {
    return Inertia::render('SuperAdmin/Login');
})->name('admin.login');

Route::post('/admin/login', [SuperAdminAuthController::class, 'login']);
Route::post('/admin/logout', [SuperAdminAuthController::class, 'logout'])->name('admin.logout');

// Super Admin web routes
Route::prefix('admin')->middleware(['super.admin.auth'])->group(function () {
    Route::get('/dashboard', [SuperAdminWebController::class, 'dashboard'])->name('admin.dashboard');
    Route::get('/hospitals/create', [SuperAdminWebController::class, 'createHospitalForm'])->name('admin.hospitals.create');
    Route::get('/hospitals/{id}', [SuperAdminWebController::class, 'hospitalDetail'])->name('admin.hospital-detail');
    Route::get('/audit-logs', [SuperAdminWebController::class, 'auditLogs'])->name('admin.audit-logs');
    Route::get('/settings', [SuperAdminWebController::class, 'settings'])->name('admin.settings');
    Route::get('/system-health', [SuperAdminWebController::class, 'systemHealth'])->name('admin.system-health');
    Route::get('/plans', [SuperAdminWebController::class, 'plans'])->name('admin.plans');
});

// Hospital Admin login (no auth required, NO tenant resolution for GET)
Route::get('/hospital-admin/login', function () {
    return Inertia::render('HospitalAdmin/Login');
})->name('hospital-admin.login');

// Hospital Admin login POST (tenant resolution required)
Route::middleware(['tenant.resolve'])->group(function () {
    Route::post('/hospital-admin/login', [HospitalAdminAuthController::class, 'login']);
});

Route::post('/hospital-admin/logout', [HospitalAdminAuthController::class, 'logout'])->name('hospital-admin.logout');

// Hospital Admin web routes (tenant resolution + auth required)
Route::prefix('hospital-admin')->middleware(['tenant.resolve', 'hospital.admin.auth'])->group(function () {
    Route::get('/dashboard', [HospitalAdminWebController::class, 'dashboard'])->name('hospital-admin.dashboard');
    Route::get('/departments', [HospitalAdminWebController::class, 'departments'])->name('hospital-admin.departments');
    Route::get('/staff', [HospitalAdminWebController::class, 'staff'])->name('hospital-admin.staff');
    Route::get('/workflow-templates', [HospitalAdminWebController::class, 'workflowTemplates'])->name('hospital-admin.workflow-templates');
    Route::get('/reports/department-activity', [HospitalAdminWebController::class, 'departmentReports'])->name('hospital-admin.reports.department');
    Route::get('/reports/financial', [HospitalAdminWebController::class, 'financialReports'])->name('hospital-admin.reports.financial');
    Route::get('/audit-logs', [HospitalAdminWebController::class, 'auditLogs'])->name('hospital-admin.audit-logs');
});

// Accounts Department web routes (tenant resolution + auth required)
Route::prefix('accounts')->middleware(['tenant.resolve', 'hospital.admin.auth'])->group(function () {
    Route::get('/queue', [AccountsWebController::class, 'queue'])->name('accounts.queue');
    Route::get('/invoices', [AccountsWebController::class, 'invoices'])->name('accounts.invoices');
    Route::get('/patient-records/{id}/create-invoice', [AccountsWebController::class, 'createInvoice'])->name('accounts.create-invoice');
    Route::get('/invoices/{id}', [AccountsWebController::class, 'invoiceDetails'])->name('accounts.invoice-details');
});

// Department web routes (HOD only — regular staff use mobile app)

// HOD login (no auth required)
Route::get('/department/login', function () {
    return Inertia::render('Department/Login');
})->name('department.login');

Route::middleware(['tenant.resolve'])->group(function () {
    Route::post('/department/login', [\App\Http\Controllers\DepartmentAuthController::class, 'login']);
});

Route::post('/department/logout', [\App\Http\Controllers\DepartmentAuthController::class, 'logout'])->name('department.logout');

// HOD dashboard (is_hod = true required)
Route::prefix('department')->middleware(['tenant.resolve', 'department.auth'])->group(function () {
    Route::get('/queue', [DepartmentWebController::class, 'queue'])->name('department.queue');
    Route::get('/patient-records/{id}', [DepartmentWebController::class, 'patientDetail'])->name('department.patient-detail');
});
// These mirror the API routes but use web session authentication
Route::prefix('hospital-admin/api')->middleware(['tenant.resolve', 'hospital.admin.auth'])->group(function () {
    // Departments
    Route::get('/departments', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'listDepartments']);
    Route::post('/departments', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'createDepartment']);
    Route::put('/departments/{id}', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'updateDepartment']);
    Route::delete('/departments/{id}', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'deleteDepartment']);

    // Staff
    Route::get('/staff', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'listStaff']);
    Route::post('/staff', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'createStaff']);
    Route::put('/staff/{id}', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'updateStaff']);
    Route::patch('/staff/{id}/deactivate', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'deactivateStaff']);

    // Workflow Templates
    Route::get('/workflows/templates', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'listWorkflowTemplates']);
    Route::post('/workflows/templates', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'createWorkflowTemplate']);
    Route::put('/workflows/templates/{id}', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'updateWorkflowTemplate']);

    // Reports
    Route::get('/reports/department-activity', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'getDepartmentActivityReport']);
    Route::get('/reports/financial', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'getFinancialReport']);

    // Audit Logs
    Route::get('/audit-logs', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'getAuditLogs']);
    Route::get('/audit-logs/export', [\App\Http\Controllers\Api\V1\HospitalAdminController::class, 'exportAuditLogs']);
});

