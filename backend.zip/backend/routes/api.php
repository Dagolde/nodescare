<?php

use App\Http\Controllers\Api\V1\AccountsController;
use App\Http\Controllers\Api\V1\AppVersionController;
use App\Http\Controllers\Api\V1\AuthController;
use App\Http\Controllers\Api\V1\ClinicalController;
use App\Http\Controllers\Api\V1\DepartmentController;
use App\Http\Controllers\Api\V1\DeviceTokenController;
use App\Http\Controllers\Api\V1\HodController;
use App\Http\Controllers\Api\V1\HospitalAdminController;
use App\Http\Controllers\Api\V1\PatientController;
use App\Http\Controllers\Api\V1\SuperAdminController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    // Super Admin routes (no tenant resolution, central DB only)
    Route::prefix('admin')->middleware(['super.admin.auth'])->group(function () {
        Route::get('/hospitals', [SuperAdminController::class, 'listHospitals']);
        Route::post('/hospitals', [SuperAdminController::class, 'createHospital']);
        Route::get('/hospitals/{id}', [SuperAdminController::class, 'getHospital']);
        Route::put('/hospitals/{id}', [SuperAdminController::class, 'updateHospital']);
        Route::patch('/hospitals/{id}/suspend', [SuperAdminController::class, 'suspendHospital']);
        Route::patch('/hospitals/{id}/activate', [SuperAdminController::class, 'activateHospital']);
        Route::get('/audit-logs', [SuperAdminController::class, 'getAuditLogs']);
        Route::get('/audit-logs/export', [SuperAdminController::class, 'exportAuditLogs']);
        Route::get('/settings', [SuperAdminController::class, 'getSettings']);
        Route::put('/settings', [SuperAdminController::class, 'updateSettings']);
        Route::get('/feature-flags', [SuperAdminController::class, 'getFeatureFlags']);
        Route::put('/feature-flags/{key}', [SuperAdminController::class, 'updateFeatureFlag']);
        Route::get('/system-health', [SuperAdminController::class, 'systemHealth']);
        Route::get('/plans', [SuperAdminController::class, 'listPlans']);
        Route::post('/plans', [SuperAdminController::class, 'createPlan']);
        Route::put('/plans/{id}', [SuperAdminController::class, 'updatePlan']);
        Route::delete('/plans/{id}', [SuperAdminController::class, 'deletePlan']);
        Route::post('/broadcast', [SuperAdminController::class, 'broadcast']);
    });

    // Authentication routes (tenant resolution only, no JWT auth required)
    Route::middleware(['tenant.resolve'])->prefix('auth')->group(function () {
        Route::post('/login', [AuthController::class, 'login']);
        Route::post('/refresh', [AuthController::class, 'refresh']);
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::post('/password/reset', [AuthController::class, 'passwordReset']);
    });

    // Mobile app version check (no auth required, tenant resolution only)
    Route::middleware(['tenant.resolve'])->prefix('app')->group(function () {
        Route::get('/version', [AppVersionController::class, 'version']);
    });

    // Protected routes - Full middleware stack applied in order:
    // 1. MaintenanceModeMiddleware - check maintenance mode
    // 2. TenantResolutionMiddleware - resolve tenant
    // 3. JWTAuthMiddleware - validate JWT
    // 4. RBACMiddleware - check permissions
    // 5. TenantScopeMiddleware - apply tenant scope
    Route::middleware(['maintenance.mode', 'tenant.resolve', 'jwt.auth', 'rbac', 'tenant.scope'])->group(function () {
        Route::get('/user', function (Request $request) {
            return response()->json([
                'success' => true,
                'data' => $request->user(),
            ]);
        });

        // Hospital Admin routes
        Route::prefix('departments')->group(function () {
            Route::get('/', [HospitalAdminController::class, 'listDepartments']);
            Route::post('/', [HospitalAdminController::class, 'createDepartment']);
            Route::put('/{id}', [HospitalAdminController::class, 'updateDepartment']);
            Route::delete('/{id}', [HospitalAdminController::class, 'deleteDepartment']);
        });

        Route::prefix('staff')->group(function () {
            Route::get('/', [HospitalAdminController::class, 'listStaff']);
            Route::post('/', [HospitalAdminController::class, 'createStaff']);
            Route::put('/{id}', [HospitalAdminController::class, 'updateStaff']);
            Route::patch('/{id}/deactivate', [HospitalAdminController::class, 'deactivateStaff']);
        });

        Route::prefix('workflows/templates')->group(function () {
            Route::get('/', [HospitalAdminController::class, 'listWorkflowTemplates']);
            Route::post('/', [HospitalAdminController::class, 'createWorkflowTemplate']);
            Route::put('/{id}', [HospitalAdminController::class, 'updateWorkflowTemplate']);
        });

        Route::prefix('reports')->group(function () {
            Route::get('/department-activity', [HospitalAdminController::class, 'getDepartmentActivityReport']);
            Route::get('/financial', [HospitalAdminController::class, 'getFinancialReport']);
        });

        Route::prefix('audit-logs')->group(function () {
            Route::get('/', [HospitalAdminController::class, 'getAuditLogs']);
            Route::get('/export', [HospitalAdminController::class, 'exportAuditLogs']);
        });

        // Department queue endpoint
        Route::get('/department/queue', [DepartmentController::class, 'getQueue']);

        // Department workflow endpoints (patient-record actions)
        Route::prefix('patient-records')->group(function () {
            Route::post('/{id}/notes', [DepartmentController::class, 'addNote']);
            Route::post('/{id}/complete', [DepartmentController::class, 'complete']);
            Route::post('/{id}/route', [DepartmentController::class, 'route']);
            Route::post('/{id}/admit', [DepartmentController::class, 'admit']);
            Route::post('/{id}/invoices', [AccountsController::class, 'createInvoice']);
            Route::get('/{id}/invoices', [AccountsController::class, 'listInvoices']);
            // Pharmacy — Dispensing endpoint (Task 12.2)
            Route::post('/{id}/dispensing', [ClinicalController::class, 'recordDispensing']);
            // Laboratory — Lab results endpoint (Task 12.3)
            Route::post('/{id}/lab-results', [ClinicalController::class, 'recordLabResults']);
        });
        // Patient Management endpoints
        Route::prefix('patients')->group(function () {
            Route::post('/', [PatientController::class, 'register']);
            Route::get('/{id}', [PatientController::class, 'show']);
            Route::get('/{id}/journey', [PatientController::class, 'journey']);
            Route::post('/{id}/documents', [PatientController::class, 'attachDocument']);
            Route::get('/{id}/documents/{docId}/url', [PatientController::class, 'getDocumentUrl']);
            Route::post('/{id}/anonymise', [PatientController::class, 'anonymise']);
        });

        // Upload pre-signed URL endpoint
        Route::get('/upload/presigned-url', [PatientController::class, 'getPresignedUploadUrl']);

        // Doctor — Appointment endpoints (Task 12.1)
        Route::prefix('appointments')->group(function () {
            Route::post('/', [ClinicalController::class, 'bookAppointment']);
            Route::get('/', [ClinicalController::class, 'listAppointments']);
            Route::patch('/{id}', [ClinicalController::class, 'updateAppointment']);
        });

        // Accounts Department endpoints
        Route::prefix('accounts')->group(function () {
            Route::get('/queue', [AccountsController::class, 'getQueue']);
        });

        // FCM device token registration
        Route::post('/device-tokens', [DeviceTokenController::class, 'store']);

        Route::prefix('invoices')->group(function () {
            Route::post('/{id}/payments', [AccountsController::class, 'recordPayment']);
            Route::post('/{id}/settle', [AccountsController::class, 'settleInvoice']);
            Route::get('/{id}/receipt', [AccountsController::class, 'generateReceipt']);
        });

        // HOD (Head of Department) staff management
        Route::prefix('my-department')->group(function () {
            Route::get('/staff', [HodController::class, 'listDepartmentStaff']);
            Route::post('/staff', [HodController::class, 'createDepartmentStaff']);
            Route::put('/staff/{id}', [HodController::class, 'updateDepartmentStaff']);
            Route::patch('/staff/{id}/deactivate', [HodController::class, 'deactivateDepartmentStaff']);
        });
    });
});
