<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tenants', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('subdomain')->unique();
            $table->enum('status', ['active', 'suspended', 'inactive'])->default('active');
            $table->uuid('plan_id')->nullable();
            $table->timestamps();
            // FK added after plans table is created (see 000002)
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tenants');
    }
};
