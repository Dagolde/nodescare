<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            // Modify the status enum to include 'failed'
            $table->enum('status', ['active', 'suspended', 'inactive', 'failed'])
                ->default('active')
                ->change();
        });
    }

    public function down(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            // Revert to original enum values
            $table->enum('status', ['active', 'suspended', 'inactive'])
                ->default('active')
                ->change();
        });
    }
};
