<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lab_results', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('patient_record_id');
            $table->uuid('technician_id');
            $table->string('test_name');
            $table->text('result_value');
            $table->string('reference_range')->nullable();
            $table->string('result_document_key', 500)->nullable();
            $table->timestamp('resulted_at');
            $table->timestamp('created_at')->useCurrent();

            $table->foreign('patient_record_id')->references('id')->on('patient_records')->onDelete('cascade');
            $table->foreign('technician_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('lab_results');
    }
};
