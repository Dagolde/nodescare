<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('patients', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('patient_number', 20)->unique();
            $table->string('full_name'); // Encrypted at application layer
            $table->date('date_of_birth'); // Encrypted at application layer
            $table->enum('gender', ['male', 'female', 'other']);
            $table->string('phone', 20); // Encrypted at application layer
            $table->text('address')->nullable(); // Encrypted at application layer
            $table->string('next_of_kin_name')->nullable();
            $table->string('next_of_kin_phone', 20)->nullable();
            $table->text('chief_complaint');
            $table->string('hmo_provider_name')->nullable();
            $table->string('hmo_policy_number')->nullable();
            $table->string('photo_object_key', 500)->nullable();
            $table->boolean('is_anonymised')->default(false);
            $table->uuid('created_by');
            $table->timestamps();

            $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('patients');
    }
};
