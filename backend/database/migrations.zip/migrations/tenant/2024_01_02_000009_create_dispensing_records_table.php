<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('dispensing_records', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('patient_record_id');
            $table->uuid('pharmacist_id');
            $table->string('drug_name');
            $table->string('dosage', 100);
            $table->string('quantity', 100);
            $table->timestamp('dispensed_at');
            $table->timestamp('created_at')->useCurrent();

            $table->foreign('patient_record_id')->references('id')->on('patient_records')->onDelete('cascade');
            $table->foreign('pharmacist_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('dispensing_records');
    }
};
