<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('patient_documents', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('patient_record_id');
            $table->uuid('uploader_id');
            $table->enum('document_type', ['registration', 'lab_result', 'prescription', 'other']);
            $table->string('object_key', 500);
            $table->string('original_filename');
            $table->integer('file_size_bytes');
            $table->timestamp('uploaded_at')->useCurrent();

            $table->foreign('patient_record_id')->references('id')->on('patient_records')->onDelete('cascade');
            $table->foreign('uploader_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('patient_documents');
    }
};
