<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * Adds indexes on frequently queried columns to improve query performance.
     */
    public function up(): void
    {
        // Index on patient_records.current_department_id (used in department queue queries)
        Schema::table('patient_records', function (Blueprint $table) {
            $table->index('current_department_id', 'idx_patient_records_current_department_id');
            $table->index('status', 'idx_patient_records_status');
        });

        // Index on invoices.status (used in financial reports and accounts queue)
        Schema::table('invoices', function (Blueprint $table) {
            $table->index('status', 'idx_invoices_status');
        });

        // Index on audit_logs.created_at (used in audit log queries with date range filters)
        Schema::table('audit_logs', function (Blueprint $table) {
            $table->index('created_at', 'idx_audit_logs_created_at');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('patient_records', function (Blueprint $table) {
            $table->dropIndex('idx_patient_records_current_department_id');
            $table->dropIndex('idx_patient_records_status');
        });

        Schema::table('invoices', function (Blueprint $table) {
            $table->dropIndex('idx_invoices_status');
        });

        Schema::table('audit_logs', function (Blueprint $table) {
            $table->dropIndex('idx_audit_logs_created_at');
        });
    }
};
