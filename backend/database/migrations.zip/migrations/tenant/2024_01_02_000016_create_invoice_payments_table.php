<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('invoice_payments', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('invoice_id');
            $table->uuid('accountant_id');
            $table->enum('payment_type', ['cash', 'pos_card', 'hmo_insurance']);
            $table->decimal('amount', 10, 2);
            $table->string('receipt_reference')->nullable();
            $table->string('hmo_provider_name')->nullable();
            $table->string('hmo_policy_number')->nullable();
            $table->string('hmo_claim_reference')->nullable();
            $table->timestamp('created_at')->useCurrent();

            $table->foreign('invoice_id')->references('id')->on('invoices')->onDelete('cascade');
            $table->foreign('accountant_id')->references('id')->on('users')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('invoice_payments');
    }
};
